# Sacar el APK sin Android Studio

1. Crea una cuenta gratis en github.com y un repositorio nuevo (privado o público).
2. Descomprime el zip y sube TODO su contenido al repositorio (Add file > Upload files, desde un navegador de PC).
3. Entra en la pestaña Actions. Se compila solo (tarda unos 5-10 min).
4. Abre la ejecución terminada y descarga el artefacto iOS-Launcher-APK (es un zip con el app-debug.apk dentro).
5. Pasa el APK al móvil, ábrelo e instálalo (permite "instalar apps desconocidas" cuando lo pida).
6. Ajustes > Apps > Apps predeterminadas > App de inicio > elige iOS Launcher.
