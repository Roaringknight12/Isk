# iOS Launcher (Android)

1. Abre la carpeta IosLauncher en Android Studio (Ladybug o superior).
2. Espera a que sincronice Gradle.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Instala el APK y elige el launcher en Ajustes > Apps > Apps predeterminadas > App de inicio.

Gestos: desliza hacia arriba para la biblioteca, mantén pulsado el fondo para añadir widgets, mantén pulsado un widget para quitarlo.
Dock: edita DEFAULT_DOCK en ui/home/HomeScreen.kt para fijar tus apps.
